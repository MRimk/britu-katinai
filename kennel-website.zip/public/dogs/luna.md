---
name: Luna
breed: Weimaraner
gender: Female
birthdate: 2021-03-15
image: /images/luna.png
---

Luna is a gentle and intelligent female with great prey drive and balanced temperament. She’s a proven mother with an excellent pedigree.

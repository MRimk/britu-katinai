import { useState } from "react";
import Home from "./pages/Home";
import Dogs from "./pages/Dogs";
import About from "./pages/About";
import Contact from "./pages/Contact";

type Page = "home" | "dogs" | "about" | "contact";

export default function App() {
  const [page, setPage] = useState<Page>("home");

  return (
    <>
      <header className="p-4 bg-gray-900 text-white">
        <div className="container mx-auto flex justify-between items-center">
          <a
            href="#"
            onClick={() => setPage("home")}
            className="text-xl font-semibold"
          >
            Kennel
          </a>
          <nav className="space-x-4">
            <button onClick={() => setPage("home")} className="hover:underline">
              Pagrindinis
            </button>
            <button onClick={() => setPage("dogs")} className="hover:underline">
              Šunys
            </button>
            <button
              onClick={() => setPage("about")}
              className="hover:underline"
            >
              Apie Mus
            </button>
            <button
              onClick={() => setPage("contact")}
              className="hover:underline"
            >
              Kontaktai
            </button>
          </nav>
        </div>
      </header>

      <main className="pt-6 container mx-auto">
        {page === "home" && <Home />}
        {page === "dogs" && <Dogs />}
        {page === "about" && <About />}
        {page === "contact" && <Contact />}
      </main>

      <footer className="mt-12 border-t pt-6 pb-4 text-center text-sm text-gray-500">
        <div className="container mx-auto space-y-2">
          <div>
            Susisiekite{" "}
            <a
              href="mailto:veisykla@example.com"
              className="text-blue-600 underline"
            >
              veisykla@example.com
            </a>{" "}
            arba{" "}
            <a href="tel:+37061768411" className="text-blue-600 underline">
              +370 617 68411
            </a>
          </div>
          <div>
            &copy; {new Date().getFullYear()} Šunų veisykla "Au Au". All rights
            reserved.
          </div>
        </div>
      </footer>
    </>
  );
}

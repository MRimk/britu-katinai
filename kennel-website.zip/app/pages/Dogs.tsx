import { useEffect, useState } from "react";
import matter from "gray-matter";

type Dog = {
  slug: string;
  name: string;
  breed: string;
  birthdate: string;
  image: string;
  description?: string;
};

export default function Dogs() {
  const [dogs, setDogs] = useState<Dog[]>([]);
  const [selectedDog, setSelectedDog] = useState<Dog | null>(null);

  useEffect(() => {
    async function loadDogs() {
      try {
        const indexRes = await fetch("/dogs/dogs.json");
        const dogList: { slug: string; file: string }[] = await indexRes.json();

        const loadedDogs = await Promise.all(
          dogList.map(async ({ slug, file }) => {
            const res = await fetch(file);
            const text = await res.text();
            const parsed = matter(text);

            return {
              slug,
              ...parsed.data,
              description: parsed.content.trim(),
            } as Dog;
          })
        );

        setDogs(loadedDogs);
      } catch (err) {
        console.error("Error loading dog list:", err);
      }
    }

    loadDogs();
  }, []);

  if (selectedDog) {
    return (
      <div className="p-6">
        <button
          onClick={() => setSelectedDog(null)}
          className="text-blue-600 underline mb-4 inline-block"
        >
          ← Grįžti į šunų sąrašą
        </button>

        <div className="max-w-2xl mx-auto p-4 border rounded shadow">
          <img
            src={selectedDog.image}
            alt={selectedDog.name}
            className="w-full h-64 object-cover rounded"
          />
          <h2 className="text-3xl font-bold mt-4">{selectedDog.name}</h2>
          <p className="text-gray-600">{selectedDog.breed}</p>
          <p className="text-gray-500">Gimimo data: {selectedDog.birthdate}</p>
          <p className="mt-4">{selectedDog.description}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
      {dogs.map((dog) => (
        <button
          key={dog.slug}
          onClick={() => setSelectedDog(dog)}
          className="text-left p-4 border rounded shadow hover:shadow-md transition"
        >
          <img
            src={dog.image}
            alt={dog.name}
            className="w-full h-48 object-cover rounded"
          />
          <h2 className="mt-2 text-xl font-bold">{dog.name}</h2>
          <p className="text-gray-600">{dog.breed}</p>
        </button>
      ))}
    </div>
  );
}
